//1. Fetch the data from the following API using the fetch function.
//  - retrieve the name, capital, population and flags for all countries.
//  - Convert the response to JSON.
//  - pass the data to the displayCountries function.
//  - Catch any errors and log them to the console.

//2. Create a displayCountries function that takes in an array of countries.
//  - Loop over the array of countries.
//      - Create a div for each country.
//      - Add the country name and flag to the div with the provided HTML structure.
//      - Add the created div to the `.countries` container element.

//3. Call the getCountries function.
//fetch

// Fetch 
fetch('https://restcountries.com/v3.1/all')
  .then(response => response.json())
  .then(data => displayCountries(data))
  .catch(error => console.error('Error:', error));

// Display countries 
function displayCountries(countries) {
  const container = document.querySelector('.countries');

  countries.forEach(country => {
    const div = document.createElement('div');
    div.className = 'country';

    div.innerHTML = `
      <h3 class="country-name">${country.name.common}</h3>
      <img class="country-flag" src="${country.flags.png}" alt="Flag of ${country.name.common}" />
      <div class="content">
        <h3>Capital</h3>
        <p>${country.capital[0]}</p>
        <h3>Population</h3>
        <p>${country.population.toLocaleString()}</p>
        <h3>Region</h3>
        <p>${country.region}</p>
      </div>
    `;

    container.appendChild(div);
  });
}
