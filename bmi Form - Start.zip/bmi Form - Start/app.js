const express = require('express')
const bodyParser = require('body-parser')
const app = express();

app.use(bodyParser.urlencoded({extended: true}));
app.set('view engine', 'html')
app.use('/static',express.static(__dirname+ '/view'));
// to use html as module source. install ejs

app.engine('html', require('ejs').renderFile);

app.get('/', (req, res) => {
    res.render('bmi', { bmi: '', weight: '', height: '' });
});

app.post('/', (req,res)=>{
    var weight = parseFloat(req.body.weight);
    var height = parseFloat(req.body.height)/100;
    var bmi = (weight/ (height*height)) ;
    res.render('bmi', {bmi: bmi.toFixed(1) , weight: req.body.weight, height: req.body.height});
})





app.listen(3000,()=>{
    console.log('Server running')
})